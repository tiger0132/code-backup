#include "testlib.h"

//

#include <algorithm>
#include <bitset>
#include <cstdio>
#include <set>

const int N = 5e4 + 45;
int n, m, k, l, det, a[N], b[N];
std::set<int> s;
int main(int argc, char *argv[]) {
	registerTestlibCmd(argc, argv);
	// in = fopen("input", "r");
	// out = fopen("user_out", "r");
	// ans = fopen("answer", "r");
	n = inf.readInt();
	m = inf.readInt();
	k = inf.readInt();
	l = inf.readInt();
	det = ans.readInt();
	a[1] = ouf.readInt();
	if (a[1] == -1 && det == -1) quitf(_ok, "no solution. OK.\n");
	if (a[1] == -1 && det == 1) quitf(_wa, "read -1, expected a_i.\n");
	for (int i = 2; i <= n; i++) {
		a[i] = ouf.readInt(0, l);
	}
	for (int i = 1; i <= m; i++) {
		b[i] = ouf.readInt(0, l);
	}
	for (int i = 1; i <= n; i++)
		for (int j = 1; j <= m; j++) s.insert(a[i] + b[j]);
	if (s.size() != k) quitf(_wa, "|{a_i + b_j}| not equal to k.\n");
	if (s.size() == k && det == -1) quitp(2, "WTF");
	quitf(_ok, "solution is correct. OK.\n");
}